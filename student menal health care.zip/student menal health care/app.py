from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import random, string
import sqlite3
from google import genai

# ---------------- APP CONFIG ----------------
app = Flask(__name__)
app.secret_key = "secret123"

app.jinja_env.globals.update(enumerate=enumerate)

client = genai.Client(api_key="AIzaSyCSev-zsKKrAE7Mx7a3NvlM4X1k-WEgyDo")


# ---------------- DATABASE ----------------
def get_db():
    conn = sqlite3.connect("stress.db")
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    conn = get_db()
    cursor = conn.cursor()

    # STUDENTS TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT,
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # STRESS RECORDS
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stress_records(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT,
        score INTEGER,
        stress_level TEXT,
        percentage INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # CHAT HISTORY
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT,
        user_message TEXT,
        bot_reply TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()


create_tables()


# ---------------- CAPTCHA ----------------
def generate_captcha():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))


# ---------------- HOME ----------------
@app.route("/")
def home():
    return redirect(url_for("login"))


# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "GET":
        captcha = generate_captcha()
        session["captcha"] = captcha
        return render_template("login.html", captcha=captcha)

    email = request.form["email"]
    password = request.form["password"]
    user_captcha = request.form["captcha"]

    if user_captcha != session.get("captcha"):
        flash("Captcha incorrect")
        return redirect(url_for("login"))

    if not email.endswith("@srmist.edu.in"):
        flash("Use SRM email only")
        return redirect(url_for("login"))

    # password must match email prefix
    roll = email.split("@")[0]

    if password != roll:
        flash("Incorrect password")
        return redirect(url_for("login"))

    session["user"] = email

    # STORE LOGIN IN DATABASE
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO students (email) VALUES (?)",
        (email,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("dashboard"))


# ---------------- SURVEY PAGE ----------------
@app.route("/dashboard")
def dashboard():

    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("index.html")


# ---------------- RECEIVE SURVEY ----------------
@app.route("/submit", methods=["POST"])
def submit():

    data = request.get_json()
    answers = data.get("answers", [])

    score = sum(answers)
    max_score = len(answers) * 5 if answers else 50 # 10 questions * 5 max = 50

    pct = max(0, round(100 - (score / max_score) * 100))

    if score <= 15:
        stress = "Low Stress"
    elif score <= 25:
        stress = "Moderate Stress"
    elif score <= 35:
        stress = "High Stress"
    else:
        stress = "Severe Stress"

    try:
        session["score"] = score
        session["pct"] = pct
        session["stress"] = stress

        # SAVE SURVEY RESULT
        conn = get_db()
        cursor = conn.cursor()

        user_email = session.get("user", "guest@test.com")
        cursor.execute(
            "INSERT INTO stress_records (roll,score,stress_level,percentage) VALUES (?,?,?,?)",
            (user_email,score,stress,pct)
        )

        conn.commit()
        conn.close()
        
        print(f"DEBUG: Submitted successfully. Score: {score}, Stress: {stress}")
        return jsonify({"status": "ok"})
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        print(f"DEBUG ERROR in /submit: {e}")
        print(error_trace)
        return jsonify({"status": "error", "message": str(e), "trace": error_trace}), 500


# ---------------- RESULT PAGE ----------------
@app.route("/result")
def result():

    user = session.get("user")
    score = session.get("score")
    stress = session.get("stress")
    
    if score is None or stress is None:
        # Fallback to last record from DB
        try:
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM stress_records WHERE roll=? ORDER BY created_at DESC LIMIT 1", (user,))
            row = cursor.fetchone()
            if row:
                score = row["score"]
                stress = row["stress_level"]
                session["score"] = score
                session["stress"] = stress
            conn.close()
        except:
            pass

    return render_template(
        "result.html",
        user=user,
        score=score,
        pct=session.get("pct", 0),
        stress=stress
    )


# ---------------- CHATBOT PAGE ----------------
@app.route("/chatbot")
def chatbot():

    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("chatbot.html")


# ---------------- GEMINI CHATBOT ----------------
@app.route("/ai_reply", methods=["POST"])
def ai_reply():

    user_message = request.get_json().get("message", "")

    stress = session.get("stress","Moderate Stress")
    user_name = session.get("user", "Student").split("@")[0]

    prompt = f"""
You are "Zenith", a highly empathetic, professional, and world-class AI counselor specializing in student mental health at SRMIST.
The student you are talking to is {user_name}.
Their current assessed stress level is: {stress}.

Context: Students face immense pressure from competitive exams, grueling assignment workloads, time management struggles, and career-path anxiety.
Goal: Provide **DETAILED, ELABORATE, and science-backed** support. Your replies should be substantive and thorough, providing not just comfort but actionable roadmaps for improvement. 

Student message: "{user_message}"

Guidelines for Perfect & Efficient Response:
1. Provide **comprehensive and elaborate** answers. Do NOT be brief. Offer multiple paragraphs of guidance.
2. Use professional yet warm language.
3. Use **Markdown formatting** (bold, bullet points, headers) to make the large amount of information easy to digest.
4. Specifically address academic pressure with techniques like the **Eisenhower Matrix** or **Progressive Muscle Relaxation**.
5. Always end with a supportive, empowering closing statement that encourages the student to keep going.

Response:
"""

    try:

        response = client.models.generate_content(
            model="gemini-1.5-flash",
            contents=prompt
        )

        reply = response.text.strip()

    except Exception as e:

        print("GEMINI ERROR:",e)
        reply = "Sorry, I couldn't respond right now."

    # SAVE CHAT HISTORY
    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO chat_history (roll,user_message,bot_reply) VALUES (?,?,?)",
            (session["user"],user_message,reply)
        )

        conn.commit()
        conn.close()
    except Exception as e:
        print("DB ERROR in chat history:", e)

    return {"reply":reply}


# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():

    session.clear()
    return redirect(url_for("login"))


# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)